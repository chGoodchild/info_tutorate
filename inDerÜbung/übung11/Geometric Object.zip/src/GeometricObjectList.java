import java.util.*;

class GeometricObjectList {
	GeometricObjectList() {
		liste = new ArrayList<GeometricObject>();
	}
	
	public void add(GeometricObject o) {
		liste.add(o);
	}
	
	public double areaSum() {
		int sum = 0;
		for (int i = 0; i < liste.size(); i++) {
			sum += liste.get(i).computeArea();
		}
		return sum;
	}
	
	public double circumferenceSum() {
		int sum = 0;
		for (int i = 0; i < liste.size(); i++) {
			sum += liste.get(i).computeCircumference();
		}
		return sum;
	}
	
	ArrayList<GeometricObject> liste;
}