interface GeometricObject {
	double computeArea();
	double computeCircumference();
}
